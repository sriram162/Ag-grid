import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

    this.title=localStorage.getItem("token");
  }
title:any="";
adds(){
  this.title="sample ls";
  localStorage.setItem("token",this.title)
}
removes(){
  
  localStorage.removeItem("token")
}
}
