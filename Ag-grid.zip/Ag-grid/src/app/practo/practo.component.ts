import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-practo',
  templateUrl: './practo.component.html',
  styleUrls: ['./practo.component.css']
})
export class PractoComponent implements OnInit {
results:any=[];
  constructor(private https:HttpClient) {
    https.get('https://jsonplaceholder.typicode.com/users')
    .subscribe(response=>{
      this.results=response;
    });
   }
   createPost(input:HTMLInputElement){
     let post={title:input.value};
this.https.post('https://jsonplaceholder.typicode.com/users',JSON.stringify(post))
.subscribe(response1=>{
console.log(response1);
});

   }

  ngOnInit(): void {
  }

}
