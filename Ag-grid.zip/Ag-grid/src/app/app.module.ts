import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TableComponent } from './table/table.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {ReactiveFormsModule } from '@angular/forms';
import{RestService}from './rest.service';
import { SearchPipe } from './search.pipe';
import { SortPipe } from './sort.pipe';
import { PractoComponent } from './practo/practo.component';
//import { SidenavComponent } from './sidenav/sidenav.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { MatSidenavModule} from '@angular/material/sidenav';
import {MatToolbarModule} from '@angular/material/toolbar';
//import { MainNavComponent } from './main-nav/main-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { MatBadgeModule } from '@angular/material/Badge';
import { RootNavComponent } from './root-nav/root-nav.component';
import {MatCardModule} from '@angular/material/card';
import { AggridComponent } from './aggrid/aggrid.component';
import{AgGridModule}from 'ag-grid-angular';
// import { Grid } from 'ag-grid-community';
@NgModule({
  declarations: [
    AppComponent,
    TableComponent,
    SearchPipe,
    SortPipe,
    PractoComponent,
    //SidenavComponent,
    //MainNavComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    RootNavComponent,
    AggridComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    MatToolbarModule,
    LayoutModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatBadgeModule,
    MatCardModule,
 
    AgGridModule.withComponents([]),
  ],
  providers: [RestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
