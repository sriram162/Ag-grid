import { Component, OnInit } from '@angular/core';
import{RestService}from '../rest.service'

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  public results:any=[]
  Emfind: any 

  constructor(private rs:RestService) { }

  ngOnInit(): void {
    this.rs.getDetails().subscribe((data)=>{
      this.results=data
console.log('checking....',this.results)
    })
  }
// search(){
//   if (this.name!=""){

//   }
//   else(this.name==""){
//   this.results=this.results.filter(res=>{
// return res.name.toLocaleLowerCase().match(this.name.toLocaleLowerCase());
//   });
// }
// }
}
