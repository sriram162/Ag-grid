import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  transform(results: any, Emfind:any):any{
    results.sort((a:any,b:any)=>{
      let x=a.name.toLowerCase();
      let y=b.name.toLowerCase();
              if (x<y){
                return -1;
              } else{
                return 1; 
              }

    }
    )
  }

}
