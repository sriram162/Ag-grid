import { Component, OnInit } from '@angular/core';


import{RestService}from '../rest.service'
import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
@Component({
  selector: 'app-aggrid',
  templateUrl: './aggrid.component.html',
  styleUrls: ['./aggrid.component.css']
})
export class AggridComponent implements OnInit {
  columnDefs = [
		{headerName: 'Id',field:'id',sortable:true,filter:true},
		{headerName: 'Username',field:'username',sortable:true,filter:true},
    {headerName: 'Name',field:'name',sortable:true,filter:true},
    {headerName: 'Email',field:'email',sortable:true,filter:true},

	
	];


  public rowData:any=[]
   gridApi:any
   gridColumnApi: any;
   searchValue:any;
   newPageSize:any;
   private paginationNumberFormatter:any;
  constructor(private rs:RestService) { }
  

  ngOnInit(): void {
    this.rs.getDetails().subscribe((data)=>{
      this.rowData=data
console.log('checking....',this.rowData)
    })
  }
  onBtExport(){
    var params={};
    this.gridApi.exportDataAsCsv(params);
 
  }

  onGridReady(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  quickSearch(){
    this.gridApi.setQuickFilter(this.searchValue);
  }

  onPageSizeChanged(event:any) {
    this.newPageSize=event.target.value
    this.gridApi.paginationSetPageSize(Number(this.newPageSize));
  }
}
