import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(results: any, Emfind:any):any {
    if (Emfind === undefined){
return results;
    }

    else{
return results.filter(
  function(x:any){
    return x.name.toLowerCase()
    .includes(Emfind.toLowerCase());
  }
)
    }




  }

}
